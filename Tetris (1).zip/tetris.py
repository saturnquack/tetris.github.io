print 'Content-Type: text/plain'
print ''
print 'You probably want /tetris ...'
